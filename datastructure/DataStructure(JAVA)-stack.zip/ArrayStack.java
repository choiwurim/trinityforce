package stack;
public class ArrayStack implements StackInterface<E>{
	private E stack[];
	private int topIndex;
	private static final int LIMITS=64;
	private final E ERROR=null;
	public ArrayStack() {
		stack=(E[])new Object[LIMITS];
		topIndex=-1;
	}
	public void push(E newItem) {
		if(isFull()) {
			// ����ó��
		}
		else {
			topIndex++;
			stack[topIndex]=newItem;
		}
	}
	public E pop() {
		if(isEmpty()) {
			return ERROR;
		}
		else {
			return stack[topIndex];
			topIndex--;
		}
	}
	public E top() {
		if(isEmpty()) {
			return ERROR;
		}
		else {
			return stack[topIndex];
		}
	}
	public boolean isEmpty() {
		if(topIndex=-1)
			return true;
		else
			return false;
	}
	public boolean isFull() {
		if(topIndex==stack.length-1)
			return true;
		else
			return false;
	}
	public E popAll() {
		stack=(E[])new Object[stack.length];
		topIndex-=1;
	}
}
