package stack;
import java.util.*;
public class ReverseString {
	// reverse �Լ�
	private static String reverse(String s) {
		ArrayStack<Character> st=new ArrayStack<>(s.length);
		for(int i=0; i<s.length; i++) {
			st.push(s.charAt(i));
		}
		String output="";
		while(!st.isEmpty()) {
			output+=st.pop();
		}
		return output;
	}
	// Ȯ��
	public static void main(String[] args) {
		String str="Hello";
		String t=reverse(str);
		System.out.println(output+"t");
	}
}
