package stack;
public class PostfixEval {
	private static int evaluate(String postfix) {
		int A,B;
		LinkedStack<Integer> s=new LinkedStack<>();
		boolean digitPrevious=false;
		for(int i=0;i<postfix.length();i++) {
			char ch=postfix.charAt(i);
			if(Character.isDigit(ch)) {
				if(digitPrevious==true) {
					int tmp=s.pop();
					tmp=10*tmp+(ch-'0');
					s.push(tmp);
				}
				else {
					s.push(ch-'0');
				}
				digitPrevious=true;
			}
			// ������ ���
			else if(isOperator(ch)) {
				A=s.pop();
				B=s.pop();
				int val=operation(A,B,ch);
				s.push(val);
				digitPrevious=false;
			}
			// ������ ���
			else {
				digitPrevious=false;
			}
		}
	}
	private static int operation(int a, int b, char ch) {
		int val=0;
		switch(ch) {
		case '*':
			val=b*a;
			break;
		case '/':
			val=b/a;
			break;
		case '+':
			val=b+a;
			break;
		case '-':
			val=b-a;
			break;
		}
		return val;
	}
	public static void main(String[] args) {
		String postfix="700 3 47 + 6 * - 4 /";
	}
}
