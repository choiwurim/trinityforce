package queue;
public interface QueueInterface<E> {
	public void enequeue(E x);
	public E dequeue();
	public E front();
	public boolean isEmpty();
	public void dequeueAll();
}
