package queue;
public class ArrayQueue<E> implements QueueInterface<E> {
	private E queue[];
	private int front, tail, numItems;
	private static final int LIMITS=64;
	private final E ERROR=null;
	
	public ArrayQueue() {
		queue=(E[]) new Object[LIMITS];
		front=0;
		tail=queue.length-1;
		numItems=0;
	}
	public void enqueue(E newItem) {
		if(isFull())
			System.out.println("Queue full");
		else {
			tail=(tail+1)%queue.length;
			queue[tail]=newItem;
			numItems++;
		}
	}
	public E dequeue() {
		if(isEmpty())
			return ERROR;
		else {
			E dequeFront=queue[front];
			front=(front+1)%queue.length;
			numItems--;
			return dequeFront;
		}
	}
	public E front() {
		if(isEmpty())
			return ERROR;
		else
			return queue[front];
	}
	public boolean isEmpty() {
		return numItems=0;
	}
	public boolean isFull() {
		return numItems==queue.length;
	}
	public void dequeAll() {
		queue=(E[])new Object[queue.length];
		front=0;
		tail=queue.length-1;
		numItems=0;
	}
}
