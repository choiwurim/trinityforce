package queue;
import stack.LinkedStack;
public class Palindrome {
	private static boolean isPalindrome(String A) {
		LinkedStack s=new LinkedStack();
		LinkedQueue q=new LinkedQueue();
		for(int i=0; i<A.length(); i++) {
			s.push(A.charAt(i));
			q.enqueue(A.charAt(i));
		}
		while(!q.isEmpty() && s.pop()==q.dequeue()) {
			if(s.isEmpty())
				return true;
			else
				return false;
		}
	}
	public static void main(String[] args) {
		String a="hello";
		String b="abbcbba";
		boolean at=isPalindrome(a);
		boolean bt=isPalindrome(b);
		System.out.println(at);
		System.out.println(bt);
	}
}
