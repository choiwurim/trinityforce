package heap;
import java.util.*;
import java.lang.*;
public class Heap<E extends Comparable> implements PQInterface<E>{
	private E[] heapArr;
	private int numItems;
	
	public Heap(int size) {
		heapArr=(E[])new Comparable[size];
		numItems=0;
	}
	public Heap(E[] array, int elementItems) {
		heapArr=array;
		numItems=elementItems;
	}
	public void insert(E newItems) throws PQException{
		
	}
}
