package heap;
public class PQException extends Exception{
	public PQException(String s) {
		super(s);
	}
}
