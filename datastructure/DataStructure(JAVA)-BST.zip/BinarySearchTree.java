package BST;
public class BinarySearchTree implements IndexInterface<TreeNode> {
	private TreeNode root;
	public BinarySearchTree() {
		root=null;
	}
	public TreeNode search(Comparable searchKey) {
		return searchItem(root, searchKey);
	}
	private TreeNode searchItem(TreeNode tNode, Comparable searchKey) {
		if(tNode==null)
			retunr null;
		else if(searchKey.compareTo(tNode.key))
	}
}
